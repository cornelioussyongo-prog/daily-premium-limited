# Daily Premium Limited

A multi-page website for a Kenyan dairy and farm business (milk from Mt Kenya, cheese, butter, fats, skin care, eggs, meat, honey and more).

## Pages
| File | What it is |
|---|---|
| `index.html` | Sign-in page (first page): phone or email plus password, with country codes |
| `home.html` | Home page |
| `story.html` | Our Story: farmers' struggles, benefits and our commitments |
| `products.html` | Product Page: 37 products with filters and search |
| `descriptions.html` | Description of every product |
| `order.html` | How to Order: steps and ways to get the products |
| `pay.html` | Pay with M-Pesa |
| `img/` | 111 product pictures (3 per product, illustrations) |

Plain HTML, CSS and JavaScript. No build step and no dependencies.

## Run it on your computer
Double-click `index.html`, or from this folder run:

    python3 -m http.server 8000

then open http://localhost:8000

## Put it online
**Vercel (drag and drop):** go to vercel.com, choose Add New, Project, and drag this whole folder in.

**GitHub + Vercel or GitHub Pages:**

    git init
    git add .
    git commit -m "Daily Premium Limited website"
    git branch -M main
    git remote add origin https://github.com/YOUR-NAME/daily-premium-limited.git
    git push -u origin main

Then import the repository in Vercel, or turn on GitHub Pages (Settings, Pages, main branch).

**Your own domain:** in Vercel open the project, Settings, Domains, and add your `.com` or `.co.ke` name. Follow the DNS steps it shows.

## Things to replace with your real details
- Phone: 0714 261 472 (used for WhatsApp, calls and M-Pesa Send Money)
- Email: hello@dailypremium.co.ke (placeholder)
- Address: "Mt Kenya region, Kenya" (placeholder)
- M-Pesa till number: in `pay.html`, set `var TILL = '';` near the bottom
- Delivery days, bulk sizes, shop stockists and prices: all placeholders
- Product pictures: replace the files in `img/` with real photos, keeping the same file names (for example `img/full-cream-milk-1.svg` can be swapped for a photo, then update the `src` in the two pages)

## Important note about sign-in
Sign-in is a front door only. Accounts and passwords are stored in each visitor's own browser (`localStorage`), so they do not work across devices and are not real security. For real accounts, SMS or email verification, you need a backend.
